/*
 * Created on Sep 13, 2004
 */
package org.sadun.util.polling.jboss;

/**
 * @author Cristiano Sadun
 */
public interface InstrumentedManagedDirectoryPollerServiceMBean
		extends
			ManagedDirectoryPollerServiceMBean {

}
